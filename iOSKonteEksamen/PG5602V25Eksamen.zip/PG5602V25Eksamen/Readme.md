# PG5602V56 Eksamen

Forutsettninger og kommentarer:

Generelt
Jeg forstår det slik på eksamensteksten at vi skal legge til kommentarer her og ikke i selve koden.
Så jeg kommer til å gå oppgave for oppgave med kommentarer fra koden.


# Oppgave 1:
Jeg var litt usikker hva som mentes med første punktet og scrolling.
Slik jeg forstod det så skal koden legges inn en ScrollView
som gjør at den passe alle typer skjermer, så jeg la det til.

GlobalStaticsView er en veldig rett frem kode.
Den bruker enkle biter av kode som vi har lært gjennom faget,
samt tidligere fag.
                                    
Den sammarbeider med GlobalAPIManager for å hente data fra APIen vi fikk tildelt i eksamensteksten. 
Av kilder brukt for koden til begge dokumentene er det fra forelesnings koden til Flight prosjektene, 
samt tidligere eksamen vi ble vist, Ratatouille
                                    
                                    
# Oppgave 2:
Veldig rett frem oppgave. Her igjen mye rett frem, enkle biter som setter sammen viewen for siden.
Denne siden er delt inn i to ulike view. En hoved view som viser alle typer krypto fra APIen i oppgave,
og en som viser detaljer bare en type krypto. For å ha kontroll på hvordan jeg skulle gå frem med å hente 
bare deler av en API, samt en API med array av flere elemtener, måtte jeg igjen se til både Ratatouille,
og min egen eksamen fra eksamen i høst. Her bruker jeg CryptoViewModel for å hente data fra APIen og 
gjør JSON responsen om til en Array av CryptoTicker objekter. 

Filen CryptoListView som viser listen, henter direkte fra CryptoViewModel for å vise alle typer krypto. 
Her kan brukeren rangere de i synkende eller stigende rekkefølgelse. Brukeren kan via picker velge rank, 1h, 24h eller 7d. 
På rank går det etter rank data fra APIen, mens i de andre går det basert på prosent endringer iløpet av en time, 24 timer og 7 dager.
Det største problemet mitt med siden er at det står pris uansett om man ser prisen eller endringer i prosent. 
Dette bli veldig misvisende for brukeren dessverre. Hadde jeg hatt mer tid hadde jeg nok fått ordnet det,
men nå ble det mye ChatGPT for å fiske koden. Dette førte til at jeg mistet kontroll på hva koden gjorde,
og det ble ChatGPT som skrev koden min og ikke meg selv. Noe jeg virkelig ikke ønsker. 

CryptoDetailView er en lett siden som viser de ulike dataene med relevant info. Dette er mye likt GlobalStaticView. 
Men her bruker jeg CryptoResponse for å hente CryptoTicker, som gir meg muligheten til å hente data bare for den ene kryptoen.


# Oppgave 3:
Litt mer komplisert oppgave med elementer vi ikke har gått gjennom i timene. Dette med å vise informasjon i diagram. 
Her måtte jeg bruke tid på å finne ut hvordan jeg skulle lage og jobbe med charts i Swift. Noe jeg fikk mye nyttig informasjon til fra
Sean Allen sin video "SwiftUI Bar Chart with Customizations | Swift Charts"
Link: https://www.youtube.com/watch?v=4utsyqhnS4g&ab_channel=SeanAllen
Først hentet jeg ut bare den informasjonen jeg trengte så jeg hadde kontroll på den biten, også bygget jeg opp en view med bare Bar Chart.

I selve hoved viewen som blir vist i "Stats" taben, CryptoSelectionView, henter denne BarChartView som inneholder Bar Charten.
Ellers bruker denne view CryptoViewModel, likt som CryptoListView, for å hente frem alle de ulike kryptoene. Denne koden er bare bygget videre
på oppgave 2, med små endringer for at det passer oppgaven. Som å bare vise navn, og la brukere velge en eller flere kryptoer. 


# Oppgave 4:
Første delen av oppgave 4 var grei å få gjort. Brukte vel mest tid her på å sette opp alt i setting så det ble bruker vennlig. 
Her gikk jeg frem med å bare bruke logikk utifra hvordan lignende funksjoner har blitt gjort gjennom forelesninger, samt andre fag.
Føler løsningen kunne blitt gjort mye bedre og mer ryddig. Men med tid og tanken på at dette er en eksamen, 
ønsket jeg ikke å endre på min egen kode som funket, mot en kode som ikke er min egen og som jeg ikke har forståelse for. 

Den største tidstyven gjennom eksamen var siste oppgave. Nemlig emoji-regn inne på statistikksiden. Her gikk det mye tid i research. 
Jeg tok mye lærdom fra videoen til Mark Moeykens, "Make It Rain Or Snow Images With The CAEmitterLayer (iOS, Xcode 8, Swift 3)"
Link: https://www.youtube.com/watch?v=Cg5GzKsMF7M&t=245s&ab_channel=MarkMoeykens
Samtidig som jeg brukte apple sin developer dokumentasjon om CAEmitterLayer:
https://developer.apple.com/documentation/quartzcore/caemitterlayer

Med disse to hjelpemiddlene fikk jeg satt sammen en kode som nesten funket som ønsket, men med et stort problem.
Jeg klarte ikke å få emojiene til å komme fra toppen av skjermen, men det ble laget et tomt felt neders på siden som viste de.
Her støttet jeg meg på AI verktøyet ChatGPT for error håndteringer. 

Prompt for ChatGPT, spurt om 24.02.2025:

I need to fix is the design on my Stats views. I have this as my main CryptoStatsView:
*CryptoStatsView kode*
But I also have this to show the BarChart Diagram:
*BarChartView kode*
On the CryptoStatsView I have the struct EmojiRainView. When that is activated it shows on the top of the section, 
but that is now under everything else, so both cryptolist and diagram. I need to rain over everything from the top and downwards


Her var da svaret:
You need to ensure that the EmojiRainView is placed above everything in the ZStack, so that it appears over both the list and the chart.

Solution: Use ZStack to Layer Views
Instead of placing EmojiRainView at the bottom, wrap your entire VStack inside a ZStack so that the emojis rain down over all content.

Så jeg gikk videre med på fikse koden med Zstack, som fikset det største av problemet. Ferdig versjon er dessverre ikke optimal. 
Jeg kunne gjerne tenkt meg å fikse på den, noe jeg sikkert kommer til å gjøre for å lære meg det ordentlig. Nå flytter EmojiRainView 
på de andre elementene når det er aktivert, samtidig som at den ikke fyller så mye av skjermen. Dessverre oppdaget jeg at jeg plutselig
brukte ChatGPT mer til å skrive koden for meg så den skulle funke som jeg ønsker, istedenfor å bare være et hjelpemiddel. Så jeg valgte
å gå tilbake til gamle versjonen hvor den funker ok, men er mitt egent arbeid bygget opp på hjelpemiddlene og kildene. 

#Kilder

Leksjonkode prosjekt Flight
Leksjonkode tidligere eksamen Ratatoullie
Egen tidligere eksamen i PG5602 Høsten 2024

Sean Allen, "SwiftUI Bar Chart with Customizations | Swift Charts"
https://www.youtube.com/watch?v=4utsyqhnS4g&ab_channel=SeanAllen

Mark Moeykens, "Make It Rain Or Snow Images With The CAEmitterLayer (iOS, Xcode 8, Swift 3)"
https://www.youtube.com/watch?v=Cg5GzKsMF7M&t=245s&ab_channel=MarkMoeykens

Apple develpoer documentation about CAEmitterLayer
https://developer.apple.com/documentation/quartzcore/caemitterlayer
