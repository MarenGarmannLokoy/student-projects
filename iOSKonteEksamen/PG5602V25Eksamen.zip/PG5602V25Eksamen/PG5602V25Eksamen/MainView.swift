import SwiftUI

struct MainView: View
{
  @AppStorage("isDarkMode") private var darkMode = false
  
  var body: some View
  {
    TabView
    {
        GlobalStaticsView().tabItem
      {
        Label("Home", systemImage: "house.fill")
      }
      
        CryptoListView().tabItem
      {
        Label("Crypto", systemImage: "dollarsign.circle.fill")
      }
      
        CryptoSelectionView().tabItem
      {
        Label("Stats", systemImage: "chart.bar.xaxis")
      }
        
        SettingView().tabItem
        {
          Label("Settings", systemImage: "gearshape.fill")
        }
        
    }
    .environment(\.colorScheme, darkMode ? .dark : .light)
  }
}

#Preview
{
  MainView()
}

 
