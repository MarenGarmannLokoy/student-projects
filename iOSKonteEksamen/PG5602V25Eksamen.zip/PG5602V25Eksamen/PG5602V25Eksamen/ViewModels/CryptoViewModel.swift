import SwiftUI
import Foundation


class CryptoViewModel: ObservableObject {
    @Published var tickers: [CryptoTicker] = []

    func fetchCryptoData() {
        guard let url = URL(string: "https://api.coinlore.net/api/tickers/") else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }
            guard let data = data else { return }

            do {
                let decodedResponse = try JSONDecoder().decode(CryptoResponse.self, from: data)
                DispatchQueue.main.async {
                    self.tickers = decodedResponse.data
                    print("Data fetched: \(self.tickers.count) cryptos")
                }
            } catch {
                print("Failed to decode: \(error.localizedDescription)")
            }
        }.resume()
    }
}


// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
