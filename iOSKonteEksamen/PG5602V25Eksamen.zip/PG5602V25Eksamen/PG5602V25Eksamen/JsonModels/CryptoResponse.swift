import Foundation

struct CryptoResponse: Codable {
    let data: [CryptoTicker]
}


struct CryptoTicker: Codable, Identifiable, Hashable {
    let id: String
    let symbol: String
    let name: String
    let rank: Int
    let price_usd: String
    let percent_change_24h: String
    let percent_change_1h: String
    let percent_change_7d: String
    let price_btc: String
    let market_cap_usd: String
    let volume24: Double
    let volume24a: Double
    let csupply: String
    let tsupply: String
    let msupply: String?
}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
