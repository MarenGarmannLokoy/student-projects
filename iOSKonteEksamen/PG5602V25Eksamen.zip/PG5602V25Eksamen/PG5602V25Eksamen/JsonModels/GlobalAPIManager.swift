import SwiftUI
import Foundation

struct GlobalAPIManager: Decodable, Hashable {
    let coins_count: Int
    let active_markets: Int
    let total_mcap: Double
    let total_volume: Double
    let btc_d: Double
    let eth_d: Double
    let mcap_change: Double
    let volume_change: Double
    let avg_change_percent: Double
    let volume_ath: Double
    let mcap_ath: Double

    enum CodingKeys: String, CodingKey {
        case coins_count, active_markets, total_mcap, total_volume, btc_d, eth_d
        case mcap_change, volume_change, avg_change_percent, volume_ath, mcap_ath
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        coins_count = try container.decode(Int.self, forKey: .coins_count)
        active_markets = try container.decode(Int.self, forKey: .active_markets)
        total_mcap = try container.decode(Double.self, forKey: .total_mcap)
        total_volume = try container.decode(Double.self, forKey: .total_volume)
        volume_ath = try container.decode(Double.self, forKey: .volume_ath)
        mcap_ath = try container.decode(Double.self, forKey: .mcap_ath)

        btc_d = Double(try container.decode(String.self, forKey: .btc_d)) ?? 0.0
        eth_d = Double(try container.decode(String.self, forKey: .eth_d)) ?? 0.0
        mcap_change = Double(try container.decode(String.self, forKey: .mcap_change)) ?? 0.0
        volume_change = Double(try container.decode(String.self, forKey: .volume_change)) ?? 0.0
        avg_change_percent = Double(try container.decode(String.self, forKey: .avg_change_percent)) ?? 0.0
    }
}


typealias GlobalAPIResponse = [GlobalAPIManager]

func getJsonCoinGlobal() async -> [GlobalAPIManager]? {
    let urlString = "https://api.coinlore.net/api/global/"

    guard let url = URL(string: urlString) else {
        print("Invalid URL")
        return nil
    }

    do {
        let (data, response) = try await URLSession.shared.data(from: url)
        
        if let httpResponse = response as? HTTPURLResponse {
            print("HTTP Response Code: \(httpResponse.statusCode)")          }

        let jsonString = String(data: data, encoding: .utf8) ?? "No data"
        print("Raw JSON Response: \(jsonString)")

        if let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) {
            let decodedResponse = try JSONDecoder().decode([GlobalAPIManager].self, from: data)
            print("Decoded Coins Count: \(decodedResponse.count)")
            return decodedResponse
        } else {
            print("HTTP request failed")
        }
    } catch {
        print("Request error: \(error)")
    }

    return nil
}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
