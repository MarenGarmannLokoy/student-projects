import SwiftUI

@main
struct PG5602V25EksamenApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
