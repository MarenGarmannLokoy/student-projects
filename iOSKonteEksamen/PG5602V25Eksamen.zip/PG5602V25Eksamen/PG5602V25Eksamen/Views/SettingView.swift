import SwiftUI

struct SettingView: View {
    @AppStorage("isDarkMode") private var darkMode = false
    @AppStorage("exchangeRate") private var exchangeRate: Double = 10.0
    @AppStorage("useNOK") private var useNOK: Bool = false
    @AppStorage("emojiThreshold") private var emojiThreshold: Int = 10
    
    
    @State private var tempExchangeRate: Double = 0
    @State private var tempEmojiThreshold: Int = 0

    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Valutakurs")) {
                    HStack {
                        Text("Valutakurs (NOK per USD)")
                        Spacer()
                        TextField("Valutakurs", value: $tempExchangeRate, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                    }
                    Button(action: {
                        exchangeRate = tempExchangeRate
                    }) {
                        Text("Oppdater valutakurs")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .padding(.top, 10)
                    
                    Text("Nåværende valutakurs: \(exchangeRate, specifier: "%.2f") NOK per USD")
                        .padding(.top, 10)
                        .foregroundColor(.blue)
                    
                    Toggle(isOn: $useNOK) {
                        Text("Vis priser i NOK")
                    }
                    .padding(.top, 10)
                }
                
                Section(header: Text("Emoji Animasjon")) {
                    HStack {
                        Text("Emoji terskel (%)")
                        Spacer()
                        TextField("Terskel", value: $tempEmojiThreshold, format: .number)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                    }
                    Button(action: {
                        emojiThreshold = tempEmojiThreshold
                    }) {
                        Text("Oppdater emoji terskel")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .padding(.top, 10)
                    
                    Text("Nåværende emoji terskel: \(emojiThreshold)%")
                        .padding(.top, 10)
                        .foregroundColor(.blue)
                }
                
                Toggle(isOn: $darkMode) {
                    Label("Aktiver mørk modus", systemImage: darkMode ? "moon.zzz" : "moon.circle")
                }
            }
            .navigationTitle("Innstillinger")
        }
        .environment(\.colorScheme, darkMode ? .dark : .light)
    }
}

#Preview {
    SettingView()
}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
