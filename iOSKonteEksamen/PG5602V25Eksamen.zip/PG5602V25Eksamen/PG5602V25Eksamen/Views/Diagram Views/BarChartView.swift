import SwiftUI
import Charts

struct BarChartView: View {
    var data: [CryptoTicker]

    var body: some View {
        VStack {
            // Kilde: Sean Allen, "SwiftUI Bar Chart with Customizations | Swift Charts"
            Chart {
                ForEach(data, id: \.id) { ticker in
                    BarMark(
                        x: .value("Kryptovaluta", ticker.name),
                        y: .value("Endring (%)", Double(ticker.percent_change_1h) ?? 0)
                    )
                    .foregroundStyle(.blue)
                    .position(by: .value("Type", "1h"))

                    BarMark(
                        x: .value("Kryptovaluta", ticker.name),
                        y: .value("Endring (%)", Double(ticker.percent_change_24h) ?? 0)
                    )
                    .foregroundStyle(.green)
                    .position(by: .value("Type", "24h"))

                    BarMark(
                        x: .value("Kryptovaluta", ticker.name),
                        y: .value("Endring (%)", Double(ticker.percent_change_7d) ?? 0)
                    )
                    .foregroundStyle(.red)
                    .position(by: .value("Type", "7d"))
                }
            }
            .chartXAxis {
                AxisMarks(position: .bottom)
            }
            .chartYAxis {
                AxisMarks(position: .leading)
            }
            .frame(height: 300)
            .padding()

            HStack {
                Text("1H Change")
                    .foregroundColor(.blue)
                Text("24H Change")
                    .foregroundColor(.green)
                Text("7D Change")
                    .foregroundColor(.red)
            }
            .padding(.top, 10)
            .font(.subheadline)
            .foregroundColor(.gray)
        }
    }
}


