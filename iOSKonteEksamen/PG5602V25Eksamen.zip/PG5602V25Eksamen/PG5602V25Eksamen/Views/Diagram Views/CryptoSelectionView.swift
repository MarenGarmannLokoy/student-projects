import SwiftUI
import UIKit

struct CryptoSelectionView: View {
    @ObservedObject var viewModel = CryptoViewModel()
    @State private var selectedCryptos: [String] = []
    @AppStorage("emojiThreshold") private var emojiThreshold: Int = 10
    @State private var showEmojis = false
    
    var body: some View {
        ZStack {
            VStack {
                Text("Velg kryptovalutaer")
                    .font(.headline)
                
                List(viewModel.tickers, id: \.id) { crypto in
                    HStack {
                        Text(crypto.name)
                        Spacer()
                        if selectedCryptos.contains(crypto.name) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.blue)
                        } else {
                            Image(systemName: "circle")
                                .foregroundColor(.gray)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        toggleSelection(for: crypto.name)
                    }
                }
                
                // Deselect All Button
                Button("Fjern merket for alle") {
                    selectedCryptos.removeAll()
                    checkForEmojiAnimation()
                }
                .padding()
                .foregroundColor(.red)
                
                if selectedCryptos.isEmpty {
                    Text("Velg minst én kryptovaluta for å vise statistikk")
                        .foregroundColor(.gray)
                } else {
                    BarChartView(data: filteredCryptoChanges)
                }
            }
            .onAppear {
                viewModel.fetchCryptoData()
                checkForEmojiAnimation()
            }

            if showEmojis {
                EmojiRainView()
                    .allowsHitTesting(true)
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                    .edgesIgnoringSafeArea(.all)
            }
        }
    }
    
    func toggleSelection(for cryptoName: String) {
        if let index = selectedCryptos.firstIndex(of: cryptoName) {
            selectedCryptos.remove(at: index)
        } else {
            selectedCryptos.append(cryptoName)
        }
        checkForEmojiAnimation()
    }
    
    var filteredCryptoChanges: [CryptoTicker] {
        viewModel.tickers.filter { selectedCryptos.contains($0.name) }
    }
    
    func checkForEmojiAnimation() {
        DispatchQueue.main.async {
            let totalChange = filteredCryptoChanges.reduce(0.0) { sum, crypto in
                let change1H = Double(crypto.percent_change_1h) ?? 0
                let change24H = Double(crypto.percent_change_24h) ?? 0
                let change7D = Double(crypto.percent_change_7d) ?? 0
                return sum + abs(change1H) + abs(change24H) + abs(change7D)
            }
            
            if totalChange > Double(emojiThreshold) {
                showEmojis = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    showEmojis = false
                }
            }
        }
    }
}
// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024


struct EmojiRainView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        let emitterLayer = CAEmitterLayer()

        emitterLayer.emitterPosition = CGPoint(x: UIScreen.main.bounds.width / 2, y: 0)
        emitterLayer.emitterSize = CGSize(width: UIScreen.main.bounds.width, height: 1)
        emitterLayer.emitterShape = .line
        emitterLayer.emitterMode = .outline

        let cell = CAEmitterCell()
        cell.birthRate = 5
        cell.lifetime = 2
        cell.velocity = 150
        cell.scale = 0.7
        cell.emissionLongitude = .pi / 2
        cell.emissionRange = .pi / 8
        cell.yAcceleration = 30

        if let emojiImage = emojiToImage(emoji: "💰", size: 25) {
            cell.contents = emojiImage.cgImage
        }
        
        emitterLayer.emitterCells = [cell]
        view.layer.addSublayer(emitterLayer)

        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}

    func emojiToImage(emoji: String, size: CGFloat) -> UIImage? {
        let font = UIFont.systemFont(ofSize: size)
        let attributes = [NSAttributedString.Key.font: font]
        let size = (emoji as NSString).size(withAttributes: attributes)

        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        (emoji as NSString).draw(at: CGPoint.zero, withAttributes: attributes)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return image
    }
}

// Kilde: Mark Moeykens, "Make It Rain Or Snow Images With The CAEmitterLayer (iOS, Xcode 8, Swift 3)"
// Apple develpoer documentation about CAEmitterLayer
