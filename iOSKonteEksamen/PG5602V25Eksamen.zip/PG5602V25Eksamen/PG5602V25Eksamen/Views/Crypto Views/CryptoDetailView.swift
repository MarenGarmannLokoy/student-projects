import SwiftUI
import Foundation

struct CryptoDetailView: View {
    let ticker: CryptoTicker
    @AppStorage("exchangeRate") private var exchangeRate: Double = 10.0
    @AppStorage("useNOK") private var useNOK: Bool = false // Get user preference

    var body: some View {
        VStack {
            Text(ticker.name)
                .font(.largeTitle)
                .padding()

            if useNOK {
                Text("Pris: \(convertToNOK(usd: Double(ticker.price_usd) ?? 0.0), specifier: "%.2f") kr")
            } else {
                Text("Pris: $\(ticker.price_usd)")
            }

            Text("1T Endringer: \(ticker.percent_change_1h)%")
            Text("24T Endringer: \(ticker.percent_change_24h)%")
            Text("7D Endringer: \(ticker.percent_change_7d)%")

            Spacer()
        }
        .padding()
    }

    func convertToNOK(usd: Double) -> Double {
        return usd * exchangeRate
    }
}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
