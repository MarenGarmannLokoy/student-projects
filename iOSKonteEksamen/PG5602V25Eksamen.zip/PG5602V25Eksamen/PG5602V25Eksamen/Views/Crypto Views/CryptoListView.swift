import SwiftUI
import Foundation

struct CryptoListView: View {
    @StateObject var viewModel = CryptoViewModel()
    @State private var sortOption: String = "rank"
    @State private var isAscending: Bool = true
    @AppStorage("exchangeRate") private var exchangeRate: Double = 10.0
    @AppStorage("useNOK") private var useNOK: Bool = false

    var sortedTickers: [CryptoTicker] {
        switch sortOption {
        case "1H":
            return viewModel.tickers.sorted { isAscending ? $0.percent_change_1h < $1.percent_change_1h : $0.percent_change_1h > $1.percent_change_1h }
        case "24H":
            return viewModel.tickers.sorted { isAscending ? $0.percent_change_24h < $1.percent_change_24h : $0.percent_change_24h > $1.percent_change_24h }
        case "7D":
            return viewModel.tickers.sorted { isAscending ? $0.percent_change_7d < $1.percent_change_7d : $0.percent_change_7d > $1.percent_change_7d }
        default:
            return viewModel.tickers.sorted { isAscending ? $0.price_usd > $1.price_usd : $0.price_usd < $1.price_usd }
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                Picker("Sorter etter:", selection: $sortOption) {
                    Text("Rank").tag("rank")
                    Text("1T endringer").tag("1H")
                    Text("24T endringer").tag("24H")
                    Text("7D endringer").tag("7D")
                }
                .pickerStyle(SegmentedPickerStyle())

               
                Button(action: {
                    isAscending.toggle()
                }) {
                    HStack {
                        Text("Sortert: ")
                            .font(.title)
                        Image(systemName: isAscending ? "arrowshape.down" : "arrowshape.up")
                        Text(isAscending ? "Synkende" : "Stigende")
                            .fontWeight(.bold)
                    }
                    .foregroundColor(.primary)
                }


                List(sortedTickers, id: \.id) { ticker in
                    NavigationLink(destination: CryptoDetailView(ticker: ticker)) {
                        VStack(alignment: .leading) {
                            Text(ticker.name)
                                .font(.headline)
                            Text(displayedPrice(for: ticker))
                                .font(.subheadline)
                        }
                    }
                }
                .navigationTitle("Liste over kryptoer")
                .onAppear {
                    viewModel.fetchCryptoData()
                }
            }
        }
    }
    
    private func displayedPrice(for ticker: CryptoTicker) -> String {
        if let priceUSD = Double(ticker.price_usd) { 
            let price = useNOK ? priceUSD * exchangeRate : priceUSD
            let currencySymbol = useNOK ? "NOK" : "USD"
            return "Pris: \(String(format: "%.2f", price)) \(currencySymbol)"
        } else {
            return "Pris: N/A"
        }
    }

}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
