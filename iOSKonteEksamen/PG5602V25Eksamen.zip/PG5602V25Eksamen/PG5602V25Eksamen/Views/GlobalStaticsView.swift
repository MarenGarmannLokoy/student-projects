import SwiftUI

struct GlobalStaticsView: View {
    @State private var coins: [GlobalAPIManager] = []
    @State private var lastUpdated: Date? = nil
    @State private var isOffline: Bool = false

    var body: some View {
        NavigationStack {
            ZStack {
                GeometryReader { geometry in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 24) {
                            if isOffline {
                                Text("Feil: Ingen nettverkstilkobling")
                                    .foregroundColor(.red)
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.white.opacity(0.8))
                                    .cornerRadius(8)
                            }
                            
                            ForEach(coins, id: \.self) { coin in
                                VStack(alignment: .leading, spacing: 16) {
                                    Group {
                                        
                                        HStack {
                                            Text("Total Coins:")
                                                .font(.headline)
                                                .fontWeight(.bold)
                                            Spacer()
                                            Text("\(coin.coins_count)")
                                                .font(.title2)
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Active Markets:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.active_markets)")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Market Cap:")
                                                .font(.headline)
                                            Spacer()
                                            Text("$\(coin.total_mcap, specifier: "%.2f")")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Trading Volume (24h):")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.total_volume, specifier: "%.2f")")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                    }
                                    
                                    Divider()
                                    
                                    Group {
                                        HStack {
                                            Text("BTC Dominance:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.btc_d, specifier: "%.2f")%")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("ETH Dominance:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.eth_d, specifier: "%.2f")%")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Market Cap Change (24h):")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.mcap_change, specifier: "%.2f")%")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Trading Volume Change (24h):")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.volume_change, specifier: "%.2f")%")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("Average Change Percent:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.avg_change_percent, specifier: "%.2f")%")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("All-Time High Trading Volume:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.volume_ath, specifier: "%.2f")")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                        
                                        HStack {
                                            Text("All-Time High Market Cap:")
                                                .font(.headline)
                                            Spacer()
                                            Text("\(coin.mcap_ath, specifier: "%.2f")")
                                                .foregroundColor(isOffline ? .red : .primary)
                                        }
                                    }
                                }
                                .padding()
                                .cornerRadius(12)
                                .shadow(radius: 5)
                                .padding(.horizontal)
                            }
                        }
                        .padding(.top)
                    }
                    .refreshable {
                        await loadCoins()
                    }
                }
            }
            .navigationTitle("Global kryptostatistikk")
            .task {
                await loadCoins()
            }
        }
    }

    func loadCoins() async {
        if let fetchedCoins = await getJsonCoinGlobal() {
            DispatchQueue.main.async {
                self.coins = fetchedCoins
                self.lastUpdated = Date()
                self.isOffline = false
            }
        } else {
            DispatchQueue.main.async {
                self.isOffline = true
            }
        }
    }
}

#Preview {
    GlobalStaticsView()
}

// Kilde: Leksjonkode prosjekt Flight
// Leksjonkode tidligere eksamen Ratatoullie
// Egen tidligere eksamen i PG5602 Høsten 2024
